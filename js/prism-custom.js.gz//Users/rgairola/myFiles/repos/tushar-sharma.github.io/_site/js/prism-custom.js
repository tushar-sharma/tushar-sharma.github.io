// Initialize Prism
document.addEventListener('DOMContentLoaded', function() {
  Prism.highlightAll();
});

// Apply whitespace normalization to code blocks
document.addEventListener('DOMContentLoaded', function() {
  Prism.plugins.NormalizeWhitespace.setDefaults({
    'remove-trailing': false,
    'remove-indent': false,
    'left-trim': false,
    'right-trim': false,
  });
});
