function decryptText(password, url) {
    const iframe = document.createElement('iframe');
    iframe.style.display = 'none';
    iframe.src = url;
    document.body.appendChild(iframe);
    
    iframe.onload = function() {
      const encryptedText = iframe.contentDocument.documentElement.innerText;
      const decryptedText = sjcl.decrypt(password, encryptedText);
      document.getElementById('decrypted-text').innerText = decryptedText;
      
      // Remove the iframe from the DOM
      document.body.removeChild(iframe);
    };
  }